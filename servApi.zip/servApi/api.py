from flask import Flask, request, jsonify
from flask_cors import CORS
import difflib
import random
from story import stories
from responses import responses
from custom_code import code_responses
from emotion import emotion_responses
from joke import jokes

app = Flask(__name__)
CORS(app)

# Define the expected origin for your chatbox website
EXPECTED_ORIGIN = 'http://127.0.0.1'  # Replace with your website URL

# Define the secret API key for unauthorized users
SECRET_API_KEY = '724725J$9P&xL#2s@F4zG90'

# List of apology responses
apologies = [
    "I'm sorry, I couldn't find an answer for that.",
    "Apologies, I'm still learning and don't have an answer.",
    "Sorry, I'm not sure about that one.",
    "My knowledge is limited, and I can't provide an answer.",
    "I deeply apologize for any inconvenience caused."
"Please understand that I'm continuously learning and improving.",
    "I'm sincerely sorry if my response was not satisfactory."
"Your feedback is important to me, and I'll strive to do better next time.",
    "My apologies for not meeting your expectations."
 "I appreciate your patience and will work to provide more accurate responses.",
    "I regret any disappointment my previous response may have caused."
"Your understanding and feedback are valuable for my improvement.",
    "I'm truly sorry for any confusion or frustration."
"I'm committed to enhancing my capabilities and responses.",
"Hmmmm i don't Find this data on my mind ?",

]

# Function to get a random apology
def get_random_apology():
    return random.choice(apologies)

# Function to generate a response for user input
def chatbot_response(user_input):
    user_input = user_input.lower()

    for word, response in emotion_responses.items():
        if word in user_input:
            return response

    for word, response in code_responses.items():
        if word in user_input:
            return response

    if user_input in emotion_responses:
        return emotion_responses[user_input]

    if user_input in code_responses:
        return code_responses[user_input]

    if user_input in responses:
        return responses[user_input]

    best_emotion_response = difflib.get_close_matches(user_input, emotion_responses.keys(), n=1, cutoff=0.7)
    best_code_response = difflib.get_close_matches(user_input, code_responses.keys(), n=1, cutoff=0.7)
    best_general_response = difflib.get_close_matches(user_input, responses.keys(), n=1, cutoff=0.7)

    response_candidates = [best_emotion_response, best_code_response, best_general_response]
    max_score = -1
    best_response = None

    for response_list in response_candidates:
        if response_list:
            response = response_list[0]
            score = difflib.SequenceMatcher(None, user_input, response).ratio()
            if score > max_score:
                max_score = score
                best_response = response

    if max_score >= 0.7:
        if best_response in emotion_responses:
            return emotion_responses[best_response]
        elif best_response in code_responses:
            return code_responses[best_response]
        else:
            return responses[best_response]

    # Handle the case where the user requests a story
    if 'tell me a story' in user_input:
        random_story = random.choice(stories)
        return random_story

    # Handle the case where the user requests a joke
    if 'tell me a joke' in user_input:
        random_joke = random.choice(jokes)
        return random_joke

    return get_random_apology()

@app.route('/chatbot', methods=['POST'])
def chatbot_endpoint():
    user_input = request.json.get('text', '')
    response = chatbot_response(user_input)
    return jsonify({"response": response})

if __name__ == '__main__':
    app.run(debug=True)
