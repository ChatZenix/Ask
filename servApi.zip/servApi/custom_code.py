code_responses  = {
    # Code for "Code a Python3 while loop"

    
    "give me code of os module in Python3": """
import os

# Example: Listing files in the current directory
file_list = os.listdir(".")
print(file_list)

# Example: Creating a new directory
os.mkdir("new_directory")
""",
    
    "give me code of sys module in Python3": """
import sys

# Example: Getting command-line arguments
args = sys.argv
print(args)

# Example: Exiting the program
sys.exit(0)
""",
    
    "give me code of math module in Python3": """
import math

# Example: Calculating square root
num = 16
sqrt_num = math.sqrt(num)
print(sqrt_num)

# Example: Calculating the factorial of a number
factorial = math.factorial(5)
print(factorial)
""",
    
    "give me code of random module in Python3": """
import random

# Example: Generating a random integer between 1 and 10
random_num = random.randint(1, 10)
print(random_num)

# Example: Shuffling a list randomly
my_list = [1, 2, 3, 4, 5]
random.shuffle(my_list)
print(my_list)
""",
    
    "give me code of time module in Python3": """
import time

# Example: Getting the current time
current_time = time.strftime("%Y-%m-%d %H:%M:%S")
print(current_time)

# Example: Pausing execution for 2 seconds
print("Start")
time.sleep(2)
print("End")
""",
    
   
    "Can you give code for a basic calculator in python3": "Certainly! Here's a simple Python calculator code:\n```python\nnum1 = float(input('Enter first number: '))\noperator = input('Enter operator (+, -, *, /): ')\nnum2 = float(input('Enter second number: '))\n\nif operator == '+':\n    result = num1 + num2\nelif operator == '-':\n    result = num1 - num2\nelif operator == '*':\n    result = num1 * num2\nelif operator == '/':\n    result = num1 / num2\nelse:\n    result = 'Invalid operator'\n\nprint(f'Result: {result}')\n```",
    "How to read a text file in Python": "You can read a text file in Python using the following code:\n```python\nfile_path = 'example.txt'\n\ntry:\n    with open(file_path, 'r') as file:\n        content = file.read()\n        print(content)\nexcept FileNotFoundError:\n    print(f'File not found: {file_path}')\n```",
    "How to write to a text file in Python": "To write to a text file in Python, you can use this code:\n```python\nfile_path = 'example.txt'\ncontent_to_write = 'This is some text to write to the file.'\n\ntry:\n    with open(file_path, 'w') as file:\n        file.write(content_to_write)\n    print(f'Content written to {file_path}')\nexcept FileNotFoundError:\n    print(f'File not found: {file_path}')\n```",
    "Can you provide a Python code for generating random numbers": "Certainly! Here's an example code to generate a random number in Python:\n```python\nimport random\n\n# Generate a random integer between 1 and 10\nrandom_number = random.randint(1, 10)\nprint(f'Random number: {random_number}')\n```",
    "How to create a Python list": "You can create a Python list by enclosing items in square brackets []. For example:\n```python\nmy_list = [1, 2, 3, 'hello', 'world']\n```",
    "How to add elements to a Python list": "You can add elements to a Python list using the `append()` method. For example:\n```python\nmy_list = [1, 2, 3]\nmy_list.append(4)\nprint(my_list)  # Output: [1, 2, 3, 4]\n```",
    "How to remove elements from a Python list": "You can remove elements from a Python list using methods like `remove()`, `pop()`, or `del`. For example:\n```python\nmy_list = [1, 2, 3, 4]\nmy_list.remove(3)  # Removes the element '3'\nprint(my_list)  # Output: [1, 2, 4]\n```",
    "How to create a Python dictionary": "You can create a Python dictionary by enclosing key-value pairs in curly braces {}. For example:\n```python\ndictionary = {'name': 'John', 'age': 30}\n```",
    "How to access values in a Python dictionary": "You can access values in a Python dictionary using keys. For example:\n```python\ndictionary = {'name': 'John', 'age': 30}\nname = dictionary['name']\nage = dictionary['age']\nprint(f'Name: {name}, Age: {age}')\n```",
    "How to check if a key exists in a Python dictionary": "You can check if a key exists in a Python dictionary using the `in` keyword or the `get()` method. For example:\n```python\ndictionary = {'name': 'John', 'age': 30}\n\n# Using 'in' keyword\nif 'name' in dictionary:\n    print('Name key exists')\n\n# Using 'get()' method\nif dictionary.get('age') is not None:\n    print('Age key exists')\n```",
    "How to iterate over elements in a Python list": "You can iterate over elements in a Python list using a `for` loop. For example:\n```python\nmy_list = [1, 2, 3, 4, 5]\nfor item in my_list:\n    print(item)\n```",
    "How to use conditional statements in Python": "You can use conditional statements like `if`, `elif`, and `else` in Python for decision-making. For example:\n```python\nx = 10\nif x > 0:\n    print('x is positive')\nelif x < 0:\n    print('x is negative')\nelse:\n    print('x is zero')\n```",
    "How to create a function in Python": "You can create a function in Python using the `def` keyword. For example:\n```python\ndef greet(name):\n    return f'Hello, {name}!'\n```",
    "How to call a function in Python": "You can call a function in Python by using its name followed by parentheses. For example:\n```python\nresult = greet('Alice')\nprint(result)  # Output: 'Hello, Alice!'\n```",
    "How to import external modules in Python": "You can import external modules in Python using the `import` keyword. For example, to import the `random` module:\n```python\nimport random\n```",
    "How to generate a random password in Python": "You can generate a random password in Python using the `random` module and string manipulation. Here's an example code:\n```python\nimport random\nimport string\n\n# Define characters for the password\ncharacters = string.ascii_letters + string.digits + string.punctuation\n\n# Generate a random password of length 12\npassword = ''.join(random.choice(characters) for _ in range(12))\nprint(f'Random Password: {password}')\n```",
    "How to open a website in Python": "You can open a website in Python using the `webbrowser` module. For example:\n```python\nimport webbrowser\n\nurl = 'https://www.example.com'\nwebbrowser.open(url)\n```",
    "How to calculate the factorial of a number in Python": "You can calculate the factorial of a number in Python using a loop or recursion. Here's an example using a loop:\n```python\ndef factorial(n):\n    result = 1\n    for i in range(1, n + 1):\n        result *= i\n    return result\n```",
    "How to find the maximum element in a list in Python": "You can find the maximum element in a list in Python using the `max()` function. For example:\n```python\nmy_list = [5, 8, 2, 10, 1]\nmax_value = max(my_list)\nprint(f'Maximum value: {max_value}')\n```",
    "How to read and parse JSON data in Python": "You can read and parse JSON data in Python using the `json` module. For example:\n```python\nimport json\n\njson_data = '{\"name\": \"Alice\", \"age\": 30}'\ndata = json.loads(json_data)\nname = data['name']\nage = data['age']\nprint(f'Name: {name}, Age: {age}')\n```",
    "How to generate a list of numbers in Python": "You can generate a list of numbers in Python using a list comprehension. For example, to generate a list of numbers from 1 to 10:\n```python\nnumbers = [x for x in range(1, 11)]\n```",
    "How to calculate the square root of a number in Python": "You can calculate the square root of a number in Python using the `math` module. For example:\n```python\nimport math\n\nnumber = 16\nsquare_root = math.sqrt(number)\nprint(f'Square root of {number} is {square_root}')\n```",
    "How to reverse a string in Python": "You can reverse a string in Python using string slicing. For example:\n```python\nmy_string = 'Hello, World!'\nreversed_string = my_string[::-1]\nprint(reversed_string)  # Output: '!dlroW ,olleH'\n```",
    "How to find the length of a string in Python": "You can find the length of a string in Python using the `len()` function. For example:\n```python\nmy_string = 'Hello, World!'\nlength = len(my_string)\nprint(f'Length of the string: {length}')\n```",
    "How to sort a list in Python": "You can sort a list in Python using the `sort()` method. For example:\n```python\nmy_list = [5, 2, 8, 1, 3]\nmy_list.sort()\nprint(my_list)  # Output: [1, 2, 3, 5, 8]\n```",
    




    "Code a Python3 while loop": """
# Initialize a variable
count = 0

# Create a while loop that runs as long as count is less than 5
while count < 5:
    # Print the current count
    print("Count:", count)
    
    # Increment count by 1
    count += 1
    # Your code here
""",

    # Code for "Define a function in Python3"
    "Define a function in Python3": """
# Define a function named 'my_function' that takes two arguments
def my_function(arg1, arg2):
    # Add arg1 and arg2 and return the result
    result = arg1 + arg2
    return result

# Call the function and store the result in a variable
result = my_function(10, 20)
print("Result:", result)
""",

    # Code for "Print 'Hello, World!' in Python3"
    "Print 'Hello, World!' in Python3": """
# Print the string 'Hello, World!'
print("Hello, World!")
""",

    # Code for "Create a Python3 list"
    "Create a Python3 list": """
# Create an empty list
my_list = []
print("Empty List:", my_list)
""",

    # Code for "Access an element in a Python3 list"
    "Access an element in a Python3 list": """
# Create a list with some elements
my_list = [10, 20, 30, 40, 50]

# Access the second element (index 1)
element = my_list[1]
print("Element at Index 1:", element)
""",

    # Code for "Append an item to a Python3 list"
    "Append an item to a Python3 list": """
# Create a list
my_list = [1, 2, 3]

# Append an item (4) to the list
my_list.append(4)

# Print the updated list
print("Updated List:", my_list)
""",

    # Code for "Create a Python3 dictionary"
    "Create a Python3 dictionary": """
# Create an empty dictionary
my_dict = {}
print("Empty Dictionary:", my_dict)
""",

    # Code for "Access a value in a Python3 dictionary"
    "Access a value in a Python3 dictionary": """
# Create a dictionary with key-value pairs
my_dict = {"name": "John", "age": 30}

# Access the value associated with the key "name"
value = my_dict["name"]
print("Value for 'name':", value)
""",

    # Code for "Add a key-value pair to a Python3 dictionary"
    "Add a key-value pair to a Python3 dictionary": """
# Create an empty dictionary
my_dict = {}

# Add a key-value pair to the dictionary
my_dict["name"] = "Alice"

# Print the updated dictionary
print("Updated Dictionary:", my_dict)
""",

    # Code for "Create a Python3 class"
    "Create a Python3 class": """
# Define a Python class named 'Person'
class Person:
    # Constructor method
    def __init__(self, name, age):
        self.name = name
        self.age = age
    
    # Method to display information about the person
    def display_info(self):
        print(f"Name: {self.name}, Age: {self.age}")

# Create an instance of the 'Person' class
person1 = Person("John", 30)

# Call the 'display_info' method to display the information
person1.display_info()
""",

    # Code for "Open and read a file in Python3"
    "Open and read a file in Python3": """
# Open a file named 'sample.txt' for reading
with open('sample.txt', 'r') as file:
    # Read the contents of the file
    content = file.read()
    
# Print the content
print("File Content:")
print(content)
""",

    # Add more code examples here...
}
